#ifndef PACKET_INJECTION_H
#define PACKET_INJECTION_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int wifi_tx_deauth_frame(uint8_t bssid[6], void *client_mac, uint16_t reason);
int wifi_tx_beacon_frame(uint8_t bssid[6], uint8_t *ssid, int ssid_len, uint8_t channel);
int wifi_tx_disassoc_frame(uint8_t bssid[6], uint8_t *client_mac, uint16_t reason);

#ifdef __cplusplus
}
#endif

#endif
