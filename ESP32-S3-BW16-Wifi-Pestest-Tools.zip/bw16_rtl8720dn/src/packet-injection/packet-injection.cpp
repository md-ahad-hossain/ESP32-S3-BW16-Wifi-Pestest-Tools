#include "packet-injection.h"
#include "wifi_conf.h"
#include "wifi_structures.h"
#include <string.h>

extern "C" {
  extern int ieee80211_raw_frame_sanity_check(int ifx, const void *buffer, int len, bool auto_seq);
}

typedef struct {
  uint16_t frame_control;
  uint16_t duration;
  uint8_t addr1[6]; // Destination
  uint8_t addr2[6]; // Source
  uint8_t addr3[6]; // BSSID
  uint16_t seq_ctrl;
} __attribute__((packed)) wifi_mgmt_header_t;

typedef struct {
  wifi_mgmt_header_t header;
  uint16_t reason;
} __attribute__((packed)) deauth_frame_t;

typedef struct {
  wifi_mgmt_header_t header;
  uint64_t timestamp;
  uint16_t beacon_interval;
  uint16_t capability;
  // Tagged parameters follow
} __attribute__((packed)) beacon_frame_t;

int wifi_tx_deauth_frame(uint8_t bssid[6], void *client_mac, uint16_t reason) {
  deauth_frame_t frame;
  
  memset(&frame, 0, sizeof(frame));
  frame.header.frame_control = 0x00C0; // Deauth
  frame.header.duration = 0x013A;
  memcpy(frame.header.addr1, client_mac ? client_mac : "\xFF\xFF\xFF\xFF\xFF\xFF", 6);
  memcpy(frame.header.addr2, bssid, 6);
  memcpy(frame.header.addr3, bssid, 6);
  frame.header.seq_ctrl = 0x0000;
  frame.reason = reason;
  
  return wifi_send_raw_frame((uint8_t*)&frame, sizeof(frame));
}

int wifi_tx_beacon_frame(uint8_t bssid[6], uint8_t *ssid, int ssid_len, uint8_t channel) {
  uint8_t buf[256];
  memset(buf, 0, sizeof(buf));
  
  // Frame control: Beacon
  buf[0] = 0x80;
  buf[1] = 0x00;
  
  // Duration
  buf[2] = 0x00;
  buf[3] = 0x00;
  
  // Destination: broadcast
  memset(&buf[4], 0xFF, 6);
  
  // Source
  memcpy(&buf[10], bssid, 6);
  
  // BSSID
  memcpy(&buf[16], bssid, 6);
  
  // Sequence control
  buf[22] = 0x00;
  buf[23] = 0x00;
  
  // Timestamp
  // (zeros are fine)
  
  // Beacon interval: 100 TU
  buf[32] = 0x64;
  buf[33] = 0x00;
  
  // Capability: ESS
  buf[34] = 0x01;
  buf[35] = 0x00;
  
  int offset = 36;
  
  // SSID tag
  buf[offset++] = 0x00;
  buf[offset++] = ssid_len;
  memcpy(&buf[offset], ssid, ssid_len);
  offset += ssid_len;
  
  // Supported rates
  buf[offset++] = 0x01;
  buf[offset++] = 0x08;
  uint8_t rates[] = {0x82, 0x84, 0x8B, 0x96, 0x0C, 0x12, 0x18, 0x24};
  memcpy(&buf[offset], rates, 8);
  offset += 8;
  
  // DS Parameter Set (channel)
  buf[offset++] = 0x03;
  buf[offset++] = 0x01;
  buf[offset++] = channel;
  
  return wifi_send_raw_frame(buf, offset);
}

int wifi_tx_disassoc_frame(uint8_t bssid[6], uint8_t *client_mac, uint16_t reason) {
  deauth_frame_t frame;
  
  memset(&frame, 0, sizeof(frame));
  frame.header.frame_control = 0x00A0; // Disassoc
  frame.header.duration = 0x013A;
  memcpy(frame.header.addr1, client_mac ? client_mac : "\xFF\xFF\xFF\xFF\xFF\xFF", 6);
  memcpy(frame.header.addr2, bssid, 6);
  memcpy(frame.header.addr3, bssid, 6);
  frame.header.seq_ctrl = 0x0000;
  frame.reason = reason;
  
  return wifi_send_raw_frame((uint8_t*)&frame, sizeof(frame));
}
