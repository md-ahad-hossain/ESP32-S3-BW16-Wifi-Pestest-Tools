/**
 * @file webserver.c
 * @brief Complete Admin Web UI for Dual-Band WiFi Security Tool
 */
#include "webserver.h"
#include "attack.h"
#include "attack_eviltwin.h"
#include "attack_jammer.h"
#include "attack_bluetooth_jammer.h"
#include "attack_beacon_spam.h"
#include "wifi_pass_verifier.h"
#include "bw16_uart.h"
#include "buzzer_led.h"
#include "wifi_controller.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_http_server.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "cJSON.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

static const char *TAG = "webserver";
static httpd_handle_t server = NULL;

// ========== URL Decode ==========
static void url_decode(const char *src, char *dst, size_t dst_size) {
    if (!src || !dst || dst_size == 0) return;
    size_t i = 0, j = 0;
    while (src[i] && j < dst_size - 1) {
        if (src[i] == '%' && i + 2 < strlen(src)) {
            char hex[3] = {src[i+1], src[i+2], 0};
            dst[j++] = (char)strtol(hex, NULL, 16);
            i += 3;
        } else if (src[i] == '+') {
            dst[j++] = ' ';
            i++;
        } else {
            dst[j++] = src[i];
            i++;
        }
    }
    dst[j] = 0;
}

// ========== Redirect Helper (AFTER url_decode, BEFORE HTML strings) ==========
static esp_err_t redirect_to(httpd_req_t *r, const char *path) {
    httpd_resp_set_status(r, "302 Found");
    httpd_resp_set_hdr(r, "Location", path);
    httpd_resp_send(r, NULL, 0);
    return ESP_OK;
}

// ========== HTML ==========
static const char* HTML_HEAD =
"<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>Dual-Band WiFi Tool</title>"
"<style>"
"*{box-sizing:border-box;margin:0;padding:0}body{background:#0a0e17;color:#e0e0e0;font-family:system-ui,sans-serif;padding:10px}"
"h1{color:#00d4ff;text-align:center;font-size:1.3em;margin:10px 0}"
".tabs{display:flex;gap:3px;margin:10px 0;flex-wrap:wrap}"
".tab{padding:8px 14px;border:none;border-radius:6px 6px 0 0;cursor:pointer;font-size:0.82em;font-weight:600;background:#1a2a3e;color:#8899aa}"
".tab.active{background:#00d4ff;color:#0a0e17}"
".page{display:none;background:#151f2e;padding:14px;border-radius:0 8px 8px 8px;min-height:350px}"
".page.active{display:block}"
".card{background:#0d1520;border-radius:8px;padding:12px;margin:8px 0;border:1px solid #1e2d42}"
".card h3{color:#00d4ff;font-size:0.95em;margin-bottom:8px}"
"table{width:100%;border-collapse:collapse;font-size:0.82em}"
"th,td{padding:6px;text-align:left;border-bottom:1px solid #1e2d42}"
"th{color:#4fc3f7;background:#0a0e17}"
"tr:hover{background:#1a2a3e}"
".btn{display:inline-block;padding:7px 16px;border:none;border-radius:6px;cursor:pointer;font-size:0.82em;font-weight:600;margin:3px;text-decoration:none}"
".btn-b{background:#00d4ff;color:#0a0e17}.btn-r{background:#ff3355;color:#fff}.btn-g{background:#00e676;color:#0a0e17}.btn-y{background:#ffab00;color:#0a0e17}.btn-v{background:#7c4dff;color:#fff}"
".btn:hover{opacity:0.85}"
".tag{padding:2px 8px;border-radius:8px;font-size:0.72em;font-weight:600}"
".tg-g{background:#00e67630;color:#00e676}.tg-r{background:#ff335530;color:#ff3355}.tg-b{background:#4fc3f730;color:#4fc3f7}.tg-y{background:#ffab0030;color:#ffab00}"
".sg{display:grid;grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:6px;margin:8px 0}"
".sb{background:#0a0e17;border-radius:6px;padding:10px;text-align:center}"
".sb .n{font-size:1.3em;font-weight:700;color:#00d4ff}.sb .l{font-size:0.72em;color:#667}"
"input{background:#0a0e17;border:1px solid #1e2d42;border-radius:4px;padding:6px 8px;color:#e0e0e0;width:160px;font-size:0.82em}"
"label{display:flex;align-items:center;gap:6px;margin:5px 0;font-size:0.82em}"
"textarea{background:#0a0e17;border:1px solid #1e2d42;border-radius:4px;color:#e0e0e0;padding:8px;font-family:monospace;width:100%}"
".log{background:#0a0e17;border-radius:4px;padding:8px;height:120px;overflow-y:auto;font-family:monospace;font-size:0.78em;color:#667}"
"@media(max-width:600px){td,th{font-size:0.72em;padding:3px}}"
"</style>"

"<script>"
"function st(n){"
"var p=document.querySelectorAll('.page');var t=document.querySelectorAll('.tab');"
"if(!p.length||!t.length)return;"
"p.forEach(x=>x.classList.remove('active'));t.forEach(x=>x.classList.remove('active'));"
"if(t[n])t[n].classList.add('active');if(p[n])p[n].classList.add('active');"
"}"
"function pg(n){st(n);fetch('/api/pg/'+n).then(r=>r.text()).then(h=>{var e=document.getElementById('p'+n);if(e)e.innerHTML=h;});}"
"setInterval(function(){"
"var x=document.getElementById('bw16tag');var s=document.getElementById('statag');if(!x||!s)return;"
"fetch('/api/stat').then(r=>r.json()).then(d=>{"
"x.className='tag '+(d.bw16?'tg-g':'tg-r');x.textContent='BW16: '+(d.bw16?'OK':'?');"
"s.className='tag '+(d.sta?'tg-g':'tg-r');s.textContent='STA: '+(d.sta?'Connected':'Disconnected');"
"}).catch(()=>{});},5000);"
"</script>"

"</head><body>"
"<h1>🔱 Dual-Band WiFi Tool <span style='font-size:0.5em;display:block;color:#667'>ESP32-S3 2.4GHz + BW16 5GHz</span></h1>"
"<div style='text-align:center;font-size:0.78em;margin:6px 0'><span class='tag tg-b'>2.4GHz: ESP32-S3</span> <span class='tag tg-y'>5GHz: BW16</span> <span id='bw16tag' class='tag tg-r'>BW16: ?</span> <span id='statag' class='tag tg-r'>STA: ?</span></div>"
"<div class='tabs'>"
"<button class='tab active' onclick='pg(0)'>📡 Scan</button>"
"<button class='tab' onclick='pg(1)'>🚫 Deauth</button>"
"<button class='tab' onclick='pg(2)'>🎭 EvilTwin</button>"
"<button class='tab' onclick='pg(3)'>📶 Jammer</button>"
"<button class='tab' onclick='pg(4)'>🔵 BT</button>"
"<button class='tab' onclick='pg(5)'>📡 Ext</button>"
"<button class='tab' onclick='pg(6)'>🐤 Ducky</button>"
"<button class='tab' onclick='pg(7)'>⚙️</button></div>";

static const char* WELCOME_HTML =
"<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>Welcome - Dual-Band WiFi Tool</title>"
"<style>"
"*{box-sizing:border-box;margin:0;padding:0}"
"body{background:#0a0e17;color:#e0e0e0;font-family:system-ui,sans-serif;display:flex;justify-content:center;align-items:center;min-height:100vh;padding:16px}"
".welcome{background:#151f2e;border-radius:16px;padding:28px;max-width:440px;width:100%;border:1px solid #1e2d42;text-align:center}"
".welcome h1{color:#00d4ff;font-size:1.4em;margin-bottom:6px}"
".welcome .sub{color:#667;font-size:0.82em;margin-bottom:20px}"
".welcome .icon{font-size:3em;margin:10px 0}"
".btn-group{display:flex;flex-direction:column;gap:10px;margin:16px 0}"
".btn{display:block;padding:14px 20px;border:none;border-radius:10px;cursor:pointer;font-size:0.95em;font-weight:600;text-decoration:none;text-align:center}"
".btn-primary{background:#00d4ff;color:#0a0e17}"
".btn-secondary{background:#1a2a3e;color:#8899aa}"
".btn-success{background:#00e676;color:#0a0e17}"
".btn:hover{opacity:0.88}"
".form-group{text-align:left;margin:12px 0}"
".form-group label{display:block;color:#8899aa;font-size:0.82em;margin-bottom:4px}"
".form-group input{width:100%;background:#0a0e17;border:1px solid #1e2d42;border-radius:8px;padding:12px;color:#e0e0e0;font-size:0.95em}"
".form-group input:focus{outline:none;border-color:#00d4ff}"
".status-bar{display:flex;justify-content:center;gap:12px;margin:10px 0;font-size:0.78em}"
".tag{padding:3px 10px;border-radius:10px;font-weight:600}"
".tg-b{background:#4fc3f730;color:#4fc3f7}.tg-y{background:#ffab0030;color:#ffab00}"
".note{color:#667;font-size:0.78em;margin-top:12px;line-height:1.4}"
"</style></head><body>"
"<div class='welcome'>"
"<div class='icon'>🔱</div>"
"<h1>Dual-Band WiFi Tool</h1>"
"<p class='sub'>ESP32-S3 2.4GHz + BW16 5GHz</p>"
"<div class='status-bar'>"
"<span class='tag tg-b'>AP: hydra</span>"
"<span id='statag' class='tag tg-y'>STA: Not Connected</span>"
"</div>"
"<div id='step1'>"
"<p style='margin:16px 0;color:#8899aa;font-size:0.9em'>Would you like to connect this device to your home WiFi router?</p>"
"<div class='btn-group'>"
"<a href='#' class='btn btn-primary' onclick='showStep2()'>✅ Yes, connect to my router</a>"
"<a href='/dashboard' class='btn btn-secondary'>⏭️ No, skip (use AP only)</a>"
"<a href='/dashboard' class='btn btn-secondary' style='border:1px solid #1e2d42'>🔑 Already have connected</a>"
"</div>"
"</div>"
"<div id='step2' style='display:none'>"
"<h3 style='color:#00d4ff;margin-bottom:12px'>🔗 Connect to Home Router</h3>"
"<form method='POST' action='/api/staconnect'>"
"<div class='form-group'><label>Router SSID</label><input type='text' name='ssid' placeholder='Enter your WiFi name' required></div>"
"<div class='form-group'><label>Router Password</label><input type='password' name='pass' placeholder='Enter WiFi password'></div>"
"<button type='submit' class='btn btn-success' style='width:100%;margin-top:8px'>🔗 Connect</button>"
"</form>"
"<p class='note'>Your credentials are stored locally on the device.<br>The AP 'hydra' will remain active.</p>"
"</div>"
"<script>"
"function showStep2(){document.getElementById('step1').style.display='none';document.getElementById('step2').style.display='block';}"
"setInterval(function(){fetch('/api/stat').then(r=>r.json()).then(d=>{"
"var s=document.getElementById('statag');"
"s.className='tag '+(d.sta?'tg-b':'tg-y');"
"s.textContent='STA: '+(d.sta?'Connected':'Not Connected');"
"if(d.sta){setTimeout(function(){window.location.href='/dashboard';},1500);}"
"}).catch(()=>{});},3000);"
"</script>"
"</div></body></html>";

// ========== Page generators ==========
static char* pg_scan(void) {
    char *b = malloc(8192); int o=0;
    o+=sprintf(b+o,"<div class='card'><h3>📡 Network Scan</h3><a href='/api/scan' class='btn btn-b'>🔄 Scan</a>"
    "<h4 style='color:#4fc3f7;margin:8px 0'>2.4 GHz (ESP32-S3)</h4>"
    "<table><tr><th>SSID</th><th>CH</th><th>BSSID</th><th>RSSI</th></tr>");
    for(int i=0;i<g_scan_result_count;i++) {
        char bssid[18]; snprintf(bssid,18,"%02X:%02X:%02X:%02X:%02X:%02X",
            g_scan_results[i].bssid[0],g_scan_results[i].bssid[1],g_scan_results[i].bssid[2],
            g_scan_results[i].bssid[3],g_scan_results[i].bssid[4],g_scan_results[i].bssid[5]);
        o+=sprintf(b+o,"<tr><td>%s</td><td>%d</td><td>%s</td><td>%d</td></tr>",
            g_scan_results[i].ssid,g_scan_results[i].primary,bssid,g_scan_results[i].rssi);
    }
    if(g_scan_result_count==0) o+=sprintf(b+o,"<tr><td colspan=4 style='color:#667;text-align:center'>Scan first</td></tr>");
    o+=sprintf(b+o,"</table><h4 style='color:#ffab00;margin:8px 0'>5 GHz (BW16)</h4>"
    "<p style='color:#667'>%" PRIu32 " networks found</p></div>",g_bw16_status.network_count);
    return b;
}

static char* pg_deauth(void) {
    char *b = malloc(8192); int o=0;
    o+=sprintf(b+o,"<div class='card'><h3>🚫 WiFi Deauther</h3>"
    "<div class='sg'><div class='sb'><div class='n'>%d</div><div class='l'>2.4G Targets</div></div>"
    "<div class='sb'><div class='n'>%" PRIu32 "</div><div class='l'>5G Targets</div></div>"
    "<div class='sb'><div class='n'>%" PRIu32 "</div><div class='l'>Frames</div></div>"
    "<div class='sb'><div class='n'><span class='tag %s'>%s</span></div><div class='l'>Status</div></div></div>"
    "<a href='/api/deauth' class='btn btn-r'>🚫 Deauth All</a> "
    "<a href='/api/dstop' class='btn btn-y'>⏹ Stop</a></div>",
    g_scan_result_count,g_bw16_status.network_count,g_bw16_status.frames_sent,
    attack_dos_is_running()?"tg-g":"tg-r",attack_dos_is_running()?"ACTIVE":"STOPPED");
    return b;
}

static char* pg_et(void) {
    char *b = malloc(4096); int o=0;
    o+=sprintf(b+o,"<div class='card'><h3>🎭 Evil Twin Attack</h3>"
    "<div style='background:#1a2a3e;border-radius:6px;padding:10px;margin:8px 0;font-size:0.82em;color:#8899aa'>"
    "<b>Native WPA2 password prompt</b> (no web page)<br>"
    "✅ Correct → Alarm+LED → real AP reappears<br>"
    "❌ Wrong → phone shows 'incorrect password'</div>"
    "<form method='POST' action='/api/etstart'>"
    "<table><tr><th>SSID</th><th>CH</th><th>BSSID</th><th>Sel</th></tr>");
    for(int i=0;i<g_scan_result_count;i++){
        char bssid[18]; snprintf(bssid,18,"%02X:%02X:%02X:%02X:%02X:%02X",
            g_scan_results[i].bssid[0],g_scan_results[i].bssid[1],g_scan_results[i].bssid[2],
            g_scan_results[i].bssid[3],g_scan_results[i].bssid[4],g_scan_results[i].bssid[5]);
        o+=sprintf(b+o,"<tr><td>%s</td><td>%d</td><td>%s</td><td><input type='radio' name='idx' value='%d'></td></tr>",
            g_scan_results[i].ssid,g_scan_results[i].primary,bssid,i);
    }
    if(g_scan_result_count==0) o+=sprintf(b+o,"<tr><td colspan=4 style='color:#667'>Scan first</td></tr>");
    o+=sprintf(b+o,"</table><input type='submit' class='btn btn-v' value='🎭 Start Evil Twin'> "
    "<a href='/api/etstop' class='btn btn-y'>⏹ Stop</a></form>"
    "<div class='card' style='background:#0a0e17;margin-top:10px'>"
    "<h3 style='font-size:0.85em'>📋 Captured Passwords</h3>"
    "<table><tr><th>SSID</th><th>Password</th><th>Status</th></tr>");
    if(g_evil_twin_result.password_captured){
        o+=sprintf(b+o,"<tr><td>%s</td><td>%s</td><td><span class='tag %s'>%s</span></td></tr>",
            g_evil_twin_result.ssid,g_evil_twin_result.captured_password,
            g_evil_twin_result.password_verified?"tg-g":"tg-y",
            g_evil_twin_result.password_verified?"VERIFIED":"PENDING");
    } else o+=sprintf(b+o,"<tr><td colspan=3 style='color:#667'>None</td></tr>");
    o+=sprintf(b+o,"</table></div></div>");
    return b;
}

static char* pg_jammer(void) {
    char *b = malloc(2048);
    sprintf(b,"<div class='card'><h3>📶 WiFi Jammer</h3><p style='color:#667;margin:8px 0'>Hides all SSIDs on both bands</p>"
    "<div class='sg'><div class='sb'><div class='n'><span class='tag %s'>%s</span></div><div class='l'>2.4GHz</div></div>"
    "<div class='sb'><div class='n'><span class='tag %s'>%s</span></div><div class='l'>5GHz (BW16)</div></div></div>"
    "<a href='/api/jstart' class='btn btn-r'>📶 Start</a> <a href='/api/jstop' class='btn btn-g'>⏹ Stop</a></div>",
    attack_jammer_is_running()?"tg-g":"tg-r",attack_jammer_is_running()?"ON":"OFF",
    g_bw16_status.jammer_active?"tg-g":"tg-r",g_bw16_status.jammer_active?"ON":"OFF");
    return b;
}

static char* pg_bt(void) {
    char *b = malloc(1024);
    sprintf(b,"<div class='card'><h3>🔵 Bluetooth Jammer</h3>"
    "<div class='sg'><div class='sb'><div class='n'><span class='tag %s'>%s</span></div><div class='l'>Status</div></div></div>"
    "<a href='/api/btstart' class='btn btn-r'>🔵 Start</a> <a href='/api/btstop' class='btn btn-g'>⏹ Stop</a></div>",
    bt_jammer_is_running()?"tg-g":"tg-r",bt_jammer_is_running()?"ACTIVE":"STOPPED");
    return b;
}

static char* pg_ext(void) {
    char *b = malloc(2048);
    sprintf(b,"<div class='card'><h3>📡 WiFi Range Extender (BW16)</h3>"
    "<form method='POST' action='/api/ext'><label>Source SSID: <input type='text' name='src' required></label>"
    "<label>Source Pass: <input type='password' name='sp'></label>"
    "<label>Ext SSID: <input type='text' name='es' value='EXT-WiFi'></label>"
    "<input type='submit' class='btn btn-b' value='📡 Start Extender'></form></div>");
    return b;
}

static char* pg_ducky(void) {
    char *b = malloc(2048);
    sprintf(b,"<div class='card'><h3>🐤 USB Rubber Ducky</h3>"
    "<form method='POST' action='/api/ducky'><textarea name='scr' rows='10'>DELAY 1000\nGUI r\nDELAY 500\nSTRING cmd\nENTER\nDELAY 500\nSTRING whoami\nENTER</textarea>"
    "<input type='submit' class='btn btn-v' value='▶️ Run'></form></div>");
    return b;
}

static char* pg_settings(void) {
    char *b = malloc(2048);
    sprintf(b,"<div class='card'><h3>⚙️ Settings</h3>"
    "<form method='POST' action='/api/set'>"
    "<label>AP SSID: <input type='text' name='ssid' value='hydra'></label>"
    "<label>AP Pass: <input type='password' name='pass' value='notforfun'></label>"
    "<input type='submit' class='btn btn-b' value='💾 Save & Reboot'></form>"
    "<div style='margin-top:15px'><a href='/api/reboot' class='btn btn-r'>🔄 Reboot</a></div></div>");
    return b;
}

// ========== Check if STA has saved credentials ==========
static bool has_saved_sta_credentials(void) {
    char ssid[32] = {0}, pass[64] = {0};
    wifictl_get_sta_creds(ssid, pass);
    return (strlen(ssid) > 0);
}

// ========== Root Handler ==========
static esp_err_t root_h(httpd_req_t *r) {
    httpd_resp_set_type(r, "text/html");

    if (has_saved_sta_credentials() && wifictl_sta_is_connected()) {
        httpd_resp_send(r, HTML_HEAD, strlen(HTML_HEAD));
        char *pages[8]={pg_scan(),pg_deauth(),pg_et(),pg_jammer(),pg_bt(),pg_ext(),pg_ducky(),pg_settings()};
        for(int i=0;i<8;i++){char tag[64];snprintf(tag,64,"<div class='page%s' id='p%d'>",i==0?" active":"",i);
            httpd_resp_sendstr(r,tag);httpd_resp_sendstr(r,pages[i]);httpd_resp_sendstr(r,"</div>");free(pages[i]);}
        httpd_resp_sendstr(r,"</body></html>");
    } else {
        httpd_resp_send(r, WELCOME_HTML, strlen(WELCOME_HTML));
    }
    return ESP_OK;
}

// ========== Dashboard Handler ==========
static esp_err_t dashboard_h(httpd_req_t *r) {
    httpd_resp_set_type(r, "text/html");
    httpd_resp_send(r, HTML_HEAD, strlen(HTML_HEAD));
    char *pages[8]={pg_scan(),pg_deauth(),pg_et(),pg_jammer(),pg_bt(),pg_ext(),pg_ducky(),pg_settings()};
    for(int i=0;i<8;i++){char tag[64];snprintf(tag,64,"<div class='page%s' id='p%d'>",i==0?" active":"",i);
        httpd_resp_sendstr(r,tag);httpd_resp_sendstr(r,pages[i]);httpd_resp_sendstr(r,"</div>");free(pages[i]);}
        httpd_resp_sendstr(r,"</body></html>");
    return ESP_OK;
}

// ========== API Handlers ==========
static esp_err_t api_pg(httpd_req_t *r) {
    int n = atoi(r->uri+8);
    char *p=NULL;
    switch(n){case 0:p=pg_scan();break;case 1:p=pg_deauth();break;case 2:p=pg_et();break;case 3:p=pg_jammer();break;case 4:p=pg_bt();break;case 5:p=pg_ext();break;case 6:p=pg_ducky();break;case 7:p=pg_settings();break;}
    if(p){httpd_resp_set_type(r,"text/html");httpd_resp_send(r,p,strlen(p));free(p);}
    return ESP_OK;
}

static esp_err_t api_stat(httpd_req_t *r) {
    cJSON *j=cJSON_CreateObject();
    cJSON_AddBoolToObject(j,"bw16",g_bw16_status.connected);
    cJSON_AddBoolToObject(j,"sta",wifictl_sta_is_connected());
    cJSON_AddBoolToObject(j,"da",attack_dos_is_running()||g_bw16_status.deauth_active);
    cJSON_AddBoolToObject(j,"ja",attack_jammer_is_running());
    cJSON_AddBoolToObject(j,"ba",bt_jammer_is_running());
    cJSON_AddBoolToObject(j,"ea",attack_eviltwin_is_running());
    cJSON_AddNumberToObject(j,"n5",g_bw16_status.network_count);
    cJSON_AddNumberToObject(j,"n24",g_scan_result_count);
    char *s=cJSON_Print(j);
    httpd_resp_set_type(r,"application/json");httpd_resp_send(r,s,strlen(s));
    cJSON_Delete(j);free(s);
    return ESP_OK;
}

static esp_err_t api_staconnect(httpd_req_t *r) {
    char buf[512];
    int ret = httpd_req_recv(r, buf, sizeof(buf) - 1);

    if (ret > 0) {
        buf[ret] = 0;
        ESP_LOGI(TAG, "STA connect: %s", buf);

        char ssid[32] = {0};
        char pass[64] = {0};

        char *p = strstr(buf, "ssid=");
        if (p) {
            p += 5;
            char *e = strchr(p, '&');
            if (e) *e = 0;
            url_decode(p, ssid, sizeof(ssid));
            if (e) *e = '&';
        }

        p = strstr(buf, "pass=");
        if (p) {
            p += 5;
            char *e = strchr(p, '&');
            if (e) *e = 0;
            url_decode(p, pass, sizeof(pass));
        }

        ESP_LOGI(TAG, "Connecting STA to: '%s'", ssid);

        if (strlen(ssid) > 0) {
            bool result = wifictl_sta_connect_home(ssid, pass);
            if (result) {
                ESP_LOGI(TAG, "Connecting to %s...", ssid);
            } else {
                ESP_LOGW(TAG, "Could not find AP: %s", ssid);
            }
        }
    }

    return redirect_to(r, "/");
}

static esp_err_t api_scan(httpd_req_t *r) {
    attack_scan_start();
    bw16_scan_5ghz();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_deauth(httpd_req_t *r) {
    attack_dos_start_broadcast();
    bw16_deauth_all();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_dstop(httpd_req_t *r) {
    attack_dos_stop();
    bw16_stop_all();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_etstart(httpd_req_t *r) {
    char buf[128];
    int ret = httpd_req_recv(r, buf, sizeof(buf)-1);
    if(ret > 0) {
        buf[ret] = 0;
        char *p = strstr(buf, "idx=");
        if(p) {
            int idx = atoi(p+4);
            if(idx >= 0 && idx < g_scan_result_count)
                attack_eviltwin_start(&g_scan_results[idx]);
        }
    }
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_etstop(httpd_req_t *r) {
    attack_eviltwin_stop();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_jstart(httpd_req_t *r) {
    attack_jammer_start();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_jstop(httpd_req_t *r) {
    attack_jammer_stop();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_btstart(httpd_req_t *r) {
    bt_jammer_start();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_btstop(httpd_req_t *r) {
    bt_jammer_stop();
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_ext(httpd_req_t *r) {
    bw16_send_command("EXTENDER:START\r\n");
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_ducky(httpd_req_t *r) {
    return redirect_to(r, "/dashboard");
}

static esp_err_t api_set(httpd_req_t *r) {
    char buf[512];
    httpd_req_recv(r, buf, sizeof(buf)-1);

    nvs_handle_t nvs;
    if(nvs_open("storage", NVS_READWRITE, &nvs) == ESP_OK) {
        nvs_set_str(nvs, "ap_ssid", "hydra");
        nvs_set_str(nvs, "ap_pass", "notforfun");
        nvs_commit(nvs);
        nvs_close(nvs);
    }

    httpd_resp_set_type(r, "text/html");
    httpd_resp_sendstr(r, "<!DOCTYPE html><html><body style='background:#0a0e17;color:#00d4ff;text-align:center;padding:40px'><h3>Saved! Rebooting...</h3></body></html>");

    vTaskDelay(pdMS_TO_TICKS(1000));
    esp_restart();
    return ESP_OK;
}

static esp_err_t api_reboot(httpd_req_t *r) {
    httpd_resp_set_type(r, "text/html");
    httpd_resp_sendstr(r, "<!DOCTYPE html><html><body style='background:#0a0e17;color:#00d4ff;text-align:center;padding:40px'><h3>🔄 Rebooting...</h3></body></html>");

    vTaskDelay(pdMS_TO_TICKS(500));
    esp_restart();
    return ESP_OK;
}

static esp_err_t api_stadisconnect(httpd_req_t *r) {
    wifictl_sta_disconnect();
    return redirect_to(r, "/dashboard");
}

static const httpd_uri_t handlers[] = {
    {"/",              HTTP_GET,  root_h,             NULL},
    {"/dashboard",     HTTP_GET,  dashboard_h,        NULL},
    {"/api/pg/*",      HTTP_GET,  api_pg,             NULL},
    {"/api/stat",      HTTP_GET,  api_stat,           NULL},
    {"/api/scan",      HTTP_GET,  api_scan,           NULL},
    {"/api/deauth",    HTTP_GET,  api_deauth,         NULL},
    {"/api/dstop",     HTTP_GET,  api_dstop,          NULL},
    {"/api/etstart",   HTTP_POST, api_etstart,        NULL},
    {"/api/etstop",    HTTP_GET,  api_etstop,         NULL},
    {"/api/jstart",    HTTP_GET,  api_jstart,         NULL},
    {"/api/jstop",     HTTP_GET,  api_jstop,          NULL},
    {"/api/btstart",   HTTP_GET,  api_btstart,        NULL},
    {"/api/btstop",    HTTP_GET,  api_btstop,         NULL},
    {"/api/ext",       HTTP_POST, api_ext,            NULL},
    {"/api/ducky",     HTTP_POST, api_ducky,          NULL},
    {"/api/set",       HTTP_POST, api_set,            NULL},
    {"/api/reboot",    HTTP_GET,  api_reboot,         NULL},
    {"/api/staconnect",HTTP_POST, api_staconnect,     NULL},
    {"/api/stadisconnect",HTTP_GET, api_stadisconnect,NULL},
};

void webserver_run(void) {
    httpd_config_t cfg=HTTPD_DEFAULT_CONFIG();
    cfg.server_port=80;
    cfg.max_uri_handlers=25;
    cfg.stack_size=16384;
    cfg.lru_purge_enable = true;
    cfg.keep_alive_enable = false;
    cfg.uri_match_fn=httpd_uri_match_wildcard;

    if(httpd_start(&server, &cfg) == ESP_OK) {
        int count = sizeof(handlers) / sizeof(handlers[0]);
        for(int i = 0; i < count; i++) {
            httpd_register_uri_handler(server, &handlers[i]);
        }
        ESP_LOGI(TAG, "🌐 Web UI: http://192.168.4.1");
    } else {
        ESP_LOGE(TAG, "Web server failed!");
    }
}
