#ifndef AP_SCANNER_H
#define AP_SCANNER_H

#include "esp_wifi_types.h"

int ap_scanner_get_count(void);
wifi_ap_record_t* ap_scanner_get_results(void);

#endif
