#include "ap_scanner.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_wifi.h"
#include <stdlib.h>

static const char *TAG = "ap_scanner";
static wifi_ap_record_t *records = NULL;
static int count = 0;

int ap_scanner_get_count(void) { return count; }
wifi_ap_record_t* ap_scanner_get_results(void) { return records; }
