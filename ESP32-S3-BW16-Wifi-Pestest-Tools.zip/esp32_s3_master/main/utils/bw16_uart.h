#ifndef BW16_UART_H
#define BW16_UART_H

#include <stdint.h>
#include <stdbool.h>
#include "driver/uart.h"
#include "driver/gpio.h"

#define BW16_UART_NUM       UART_NUM_2
#define BW16_UART_TX_PIN    GPIO_NUM_17
#define BW16_UART_RX_PIN    GPIO_NUM_18
#define BW16_UART_BAUD      115200
#define BW16_UART_BUF_SIZE  1024

typedef struct {
    bool connected;
    bool deauth_active;
    bool jammer_active;
    uint32_t frames_sent;
    uint32_t network_count;
    char last_response[256];
} bw16_status_t;

extern bw16_status_t g_bw16_status;

void bw16_uart_init(void);
void bw16_send_command(const char *cmd);
void bw16_send_formatted(const char *fmt, ...);
bool bw16_is_connected(void);
void bw16_handle_uart_rx(void);
const char* bw16_get_last_response(void);
void bw16_scan_5ghz(void);
void bw16_deauth_all(void);
void bw16_jammer_start(void);
void bw16_jammer_stop(void);
void bw16_stop_all(void);

#endif
