#include "bw16_uart.h"
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_err.h"

static const char *TAG = "bw16_uart";
bw16_status_t g_bw16_status = {0};
static char rx_buffer[BW16_UART_BUF_SIZE];
static int rx_index = 0;

void bw16_uart_init(void) {
    uart_config_t uart_config = {
        .baud_rate = BW16_UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    ESP_ERROR_CHECK(uart_param_config(BW16_UART_NUM, &uart_config));
    ESP_ERROR_CHECK(uart_set_pin(BW16_UART_NUM, BW16_UART_TX_PIN, BW16_UART_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(BW16_UART_NUM, BW16_UART_BUF_SIZE * 2, 0, 0, NULL, 0));
    g_bw16_status.connected = false;
    ESP_LOGI(TAG, "UART2 initialized TX=GPIO17 RX=GPIO18 @115200");
}

void bw16_send_command(const char *cmd) {
    size_t len = strlen(cmd);
    uart_write_bytes(BW16_UART_NUM, cmd, len);
    ESP_LOGD(TAG, "TX->BW16: %s", cmd);
}

void bw16_send_formatted(const char *fmt, ...) {
    char buf[256];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    bw16_send_command(buf);
}

void bw16_handle_uart_rx(void) {
    uint8_t data;
    while (uart_read_bytes(BW16_UART_NUM, &data, 1, 0) > 0) {
        if (data == '\n' || rx_index >= BW16_UART_BUF_SIZE - 1) {
            rx_buffer[rx_index] = '\0';
            ESP_LOGD(TAG, "RX<-BW16: %s", rx_buffer);
            if (strstr(rx_buffer, "PONG")) g_bw16_status.connected = true;
            else if (strstr(rx_buffer, "BW16_READY")) g_bw16_status.connected = true;
            else if (strstr(rx_buffer, "SCAN_RESULT:")) {
                char *p = rx_buffer + 12;
                g_bw16_status.network_count = atoi(p);
            }
            else if (strstr(rx_buffer, "DEAUTH_STARTED") || strstr(rx_buffer, "DEAUTHING")) 
                g_bw16_status.deauth_active = true;
            else if (strstr(rx_buffer, "JAMMING_ACTIVE")) 
                g_bw16_status.jammer_active = true;
            else if (strstr(rx_buffer, "ALL_STOPPED") || strstr(rx_buffer, "JAMMING_STOPPED")) {
                g_bw16_status.deauth_active = false;
                g_bw16_status.jammer_active = false;
            }
            strncpy(g_bw16_status.last_response, rx_buffer, sizeof(g_bw16_status.last_response)-1);
            rx_index = 0;
        } else {
            rx_buffer[rx_index++] = (char)data;
        }
    }
}

bool bw16_is_connected(void) { return g_bw16_status.connected; }
const char* bw16_get_last_response(void) { return g_bw16_status.last_response; }

void bw16_scan_5ghz(void) { bw16_send_command("SCAN_5GHZ\r\n"); }
void bw16_deauth_all(void) { bw16_send_command("DEAUTH_ALL\r\n"); }
void bw16_jammer_start(void) { bw16_send_command("JAMMER:START\r\n"); }
void bw16_jammer_stop(void) { bw16_send_command("JAMMER:STOP\r\n"); }
void bw16_stop_all(void) { bw16_send_command("STOP\r\n"); }
