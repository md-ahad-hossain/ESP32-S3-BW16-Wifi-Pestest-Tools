/**
 * @file main.c
 * @author HackerAI
 * @brief Main entry - ESP32-S3 Master + BW16 5GHz
 *        Dual Mode: SoftAP always ON + STA (Home Router) on demand
 */
#include <stdio.h>
#include <string.h>
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "esp_wifi.h"
#include "attack.h"
#include "wifi_controller.h"
#include "webserver.h"
#include "utils/bw16_uart.h"
#include "hardware/buzzer_led.h"

static const char* TAG = "main";

void app_main(void) {
    ESP_LOGI(TAG, "===== Dual-Band WiFi Security Tool ======");
    ESP_LOGI(TAG, "Board: ESP32-S3 (N16R8) + BW16 RTL8720dn");
    ESP_LOGI(TAG, "2.4GHz: ESP32-S3 | 5GHz: BW16 via UART");

    // Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    
    // Initialize hardware
    bw16_uart_init();
    hw_init();
    
    // Start Management AP (Soft AP "hydra" always active)
    wifictl_mgmt_ap_start();
    
    // Auto-connect to saved home router if credentials exist
    // SoftAP stays active even when STA connects
    wifictl_auto_connect_saved();
    
    // Initialize attacks
    attack_init();
    
    // Start web server
    webserver_run();

    // Ping BW16 module
    bw16_send_command("PING\r\n");
    vTaskDelay(pdMS_TO_TICKS(500));
    bw16_handle_uart_rx();

    ESP_LOGI(TAG, "===========================================");
    ESP_LOGI(TAG, "✅ SYSTEM READY");
    ESP_LOGI(TAG, "📡 AP 'hydra' at 192.168.4.1 (always on)");
    ESP_LOGI(TAG, "🔗 STA Mode: auto-connect to saved router");
    ESP_LOGI(TAG, "🌐 Web UI: http://192.168.4.1");
    ESP_LOGI(TAG, "===========================================");
}
