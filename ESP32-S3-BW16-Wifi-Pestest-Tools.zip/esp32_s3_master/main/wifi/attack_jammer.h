#ifndef ATTACK_JAMMER_H
#define ATTACK_JAMMER_H

#include <stdbool.h>

void attack_jammer_start(void);
void attack_jammer_stop(void);
bool attack_jammer_is_running(void);

#endif
