#include "attack.h"
#include "wifi_controller.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include <string.h>

static const char *TAG = "attack";

int g_scan_result_count = 0;
wifi_ap_record_t *g_scan_results = NULL;
wifi_ap_record_t g_first_ap = {0};
static bool scanning = false;

void attack_scan_done_handler(void *arg, esp_event_base_t base, int32_t id, void *data) {
    uint16_t count = 0;
    esp_wifi_scan_get_ap_num(&count);
    if (count == 0) { scanning = false; return; }
    
    if (g_scan_results) free(g_scan_results);
    g_scan_results = (wifi_ap_record_t*)calloc(count, sizeof(wifi_ap_record_t));
    
    esp_wifi_scan_get_ap_records(&count, g_scan_results);
    g_scan_result_count = count;
    
    if (count > 0) memcpy(&g_first_ap, &g_scan_results[0], sizeof(wifi_ap_record_t));
    
    ESP_LOGI(TAG, "Scan complete: %d networks found", count);
    for (int i = 0; i < count && i < 5; i++) {
        ESP_LOGI(TAG, "  %2d. %-32s CH:%2d RSSI:%4d", 
            i, g_scan_results[i].ssid, g_scan_results[i].primary, g_scan_results[i].rssi);
    }
    scanning = false;
}

void attack_init(void) {
    esp_event_handler_register(WIFI_EVENT, WIFI_EVENT_SCAN_DONE,
                                attack_scan_done_handler, NULL);
    wifictl_set_scan_done_handler(attack_scan_done_handler);  // ← এটা যোগ করো
    ESP_LOGI(TAG, "Attack system initialized");
}

void attack_scan_start(void) {
    if (scanning) return;
    scanning = true;
    
    wifi_scan_config_t scan_conf = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
        .scan_time.active.min = 120,
        .scan_time.active.max = 120,
    };
    
    esp_wifi_scan_start(&scan_conf, false);
    ESP_LOGI(TAG, "Scanning started...");
}

bool attack_is_scanning(void) { return scanning; }

static bool dos_running = false;

void attack_dos_start_broadcast(void) {
    dos_running = true;
    ESP_LOGI(TAG, "DoS broadcast attack started on 2.4GHz");
}

void attack_dos_stop(void) {
    dos_running = false;
    ESP_LOGI(TAG, "DoS attack stopped");
}

bool attack_dos_is_running(void) { return dos_running; }
