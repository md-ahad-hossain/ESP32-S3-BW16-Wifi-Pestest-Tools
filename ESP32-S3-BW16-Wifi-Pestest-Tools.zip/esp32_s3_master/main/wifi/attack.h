#ifndef ATTACK_H
#define ATTACK_H

#include "esp_wifi_types.h"
#include <stdbool.h>
#include <stdint.h>

#define MAX_ATTACK_TARGETS 10

typedef struct {
    wifi_ap_record_t *ap_records[MAX_ATTACK_TARGETS];
    int target_count;
    int method;
} attack_config_t;

extern int g_scan_result_count;
extern wifi_ap_record_t *g_scan_results;
extern wifi_ap_record_t g_first_ap;

void attack_init(void);
void attack_scan_start(void);
bool attack_is_scanning(void);
void attack_scan_done_handler(void *arg, esp_event_base_t base,
                               int32_t id, void *data);
void attack_dos_start_broadcast(void);
void attack_dos_stop(void);
bool attack_dos_is_running(void);

#endif
