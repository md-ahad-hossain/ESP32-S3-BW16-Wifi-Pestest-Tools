#include "attack_probe.h"
#include "esp_wifi.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"

static const char *TAG = "probe";

void probe_spam_start(void) {
    ESP_LOGI(TAG, "Probe request spam started");
}

void probe_spam_stop(void) {
    ESP_LOGI(TAG, "Probe request spam stopped");
}
