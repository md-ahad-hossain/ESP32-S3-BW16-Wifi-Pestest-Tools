#ifndef ATTACK_PROBE_H
#define ATTACK_PROBE_H

#include <stdbool.h>

void probe_spam_start(void);
void probe_spam_stop(void);

#endif
