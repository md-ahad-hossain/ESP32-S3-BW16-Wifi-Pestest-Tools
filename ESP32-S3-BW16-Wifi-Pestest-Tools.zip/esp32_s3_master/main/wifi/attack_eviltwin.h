#ifndef ATTACK_EVILTWIN_H
#define ATTACK_EVILTWIN_H

#include "attack.h"
#include <stdbool.h>

#define EVILTWIN_MAX_PASS_LEN 64

typedef struct {
    char ssid[33];
    uint8_t bssid[6];
    uint8_t channel;
    bool is_5ghz;
    char captured_password[EVILTWIN_MAX_PASS_LEN + 1];
    bool password_captured;
    bool password_verified;
} evil_twin_result_t;

extern evil_twin_result_t g_evil_twin_result;

void attack_eviltwin_start(const wifi_ap_record_t *ap_record);
void attack_eviltwin_submit_password(const char *password);
void attack_eviltwin_stop(void);
bool attack_eviltwin_is_running(void);
evil_twin_result_t* attack_eviltwin_get_result(void);

#endif
