#ifndef ATTACK_BEACON_SPAM_H
#define ATTACK_BEACON_SPAM_H

#include <stdbool.h>

void beacon_spam_start(int count);
void beacon_spam_stop(void);
bool beacon_spam_is_running(void);

#endif
