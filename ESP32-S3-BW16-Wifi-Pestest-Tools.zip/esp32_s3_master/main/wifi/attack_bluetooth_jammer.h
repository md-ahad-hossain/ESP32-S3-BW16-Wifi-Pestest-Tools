#ifndef ATTACK_BLUETOOTH_JAMMER_H
#define ATTACK_BLUETOOTH_JAMMER_H

#include <stdbool.h>

void bt_jammer_start(void);
void bt_jammer_stop(void);
bool bt_jammer_is_running(void);

#endif
